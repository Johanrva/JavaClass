package com.testMaven.testMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
